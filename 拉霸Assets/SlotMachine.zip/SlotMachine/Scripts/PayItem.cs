﻿using UnityEngine;
using UnityEngine.UI;
using System.Collections;

public class PayItem : MonoBehaviour {
    public Image sprite;
    public Text[] labels;
}
