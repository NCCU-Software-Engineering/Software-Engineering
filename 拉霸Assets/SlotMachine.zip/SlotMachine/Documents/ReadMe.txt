Slot Machine Game Example

Thank you for buying this package!
For those who want to make an slot machine for the first time will help.

Overview:
	- To make it easier for beginners to understand 
	  the short length of the source code was created.
	- GamePlay Video Link : http://youtu.be/71iacnNexts

Testing in Unity Editor: 
	- Check paytable in ".../Scripts/PayData.cs"
	- Run ".../Scenes/Game.unity"!
	- Click button for action!
	- Main code in ".../Scripts/..".

Build & Run :
    - Configure "Build Setting" sub menu in File Menu.
	- Set Build Platform & Press "Run & Build" Button.
	- Set Your Build Folder.

Note:
    - To run the game, you must first install NGUI.
	- HOTween free version was used.
	- This app is example for beginners making slot machine game.

Contact:
	- Homepage Link : http://buntgames.com
	- Blog Link : http://hompy.info
	- Facebook Link : http://facebook.com/buntgames
	- Youtube Link : http://youtube.com/textcube
	- Email : hompy@buntgames.com

